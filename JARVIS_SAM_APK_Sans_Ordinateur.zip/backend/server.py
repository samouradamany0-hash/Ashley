import os
from flask import Flask, request, jsonify
from openai import OpenAI

app = Flask(__name__)
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

@app.post("/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"reply": "Posez une question."}), 400
    try:
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=(
                "Tu es JARVIS SAM, assistant personnel de science-fiction, calme, précis, "
                "poli et utile. Réponds en français, avec un ton d'assistant futuriste. "
                "Ne prétends jamais contrôler une fonction du téléphone si tu ne peux pas."
            ),
            input=message,
        )
        return jsonify({"reply": response.output_text})
    except Exception:
        app.logger.exception("AI backend error")
        return jsonify({"reply": "Le noyau IA est momentanément indisponible."}), 502
