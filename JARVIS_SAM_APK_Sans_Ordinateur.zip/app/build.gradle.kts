plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sam.jarvissam"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sam.jarvissam"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
