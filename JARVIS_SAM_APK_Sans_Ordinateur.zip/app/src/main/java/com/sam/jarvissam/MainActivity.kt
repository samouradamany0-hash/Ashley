package com.sam.jarvissam

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var endpointInput: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val micRequest = 402

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildInterface()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
        }
    }

    private fun buildInterface() {
        val bg = android.graphics.Color.rgb(4, 9, 20)
        val cyan = android.graphics.Color.rgb(55, 205, 255)
        val white = android.graphics.Color.WHITE
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(bg)
        }
        fun label(value: String, size: Float, color: Int = white) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        }

        root.addView(label("J.A.R.V.I.S  S.A.M", 27f, cyan))
        root.addView(label("PERSONAL AI • SYSTEM ONLINE", 10f, android.graphics.Color.LTGRAY))
        root.addView(label("◉", 86f, cyan).apply { setPadding(0, 18, 0, 10) })
        status = label("Prêt à recevoir vos instructions.", 14f)
        root.addView(status)

        transcript = label("JARVIS SAM : Bonjour. Je suis prêt à vous assister.", 16f)
        transcript.setPadding(12, 18, 12, 18)
        transcript.setBackgroundColor(android.graphics.Color.rgb(13, 26, 44))
        root.addView(transcript, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = 18; bottomMargin = 12
        })

        input = EditText(this).apply {
            hint = "Parlez ou écrivez une commande…"
            setHintTextColor(android.graphics.Color.GRAY)
            setTextColor(white)
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                val q = input.text.toString(); input.setText(""); command(q); true
            } else false
        }

        endpointInput = EditText(this).apply {
            hint = "URL HTTPS du serveur IA (facultatif)"
            setHintTextColor(android.graphics.Color.GRAY)
            setTextColor(white)
            setSingleLine(true)
            textSize = 12f
        }
        root.addView(endpointInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(label("L'IA avancée nécessite un serveur sécurisé.", 10f, android.graphics.Color.LTGRAY))

        val buttons = LinearLayout(this).apply { gravity = Gravity.CENTER }
        buttons.addView(Button(this).apply {
            text = "🎙 PARLER"
            setOnClickListener { startListening() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 })
        buttons.addView(Button(this).apply {
            text = "ENVOYER"
            setOnClickListener {
                val q = input.text.toString().trim(); input.setText("")
                if (q.isNotEmpty()) command(q)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        setContentView(root)
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.FRANCE)
            // Android uses the installed speech engine's available French voice.
            tts.setSpeechRate(0.88f)
            tts.setPitch(0.82f)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                runOnUiThread { status.text = "Installe une voix française dans les paramètres de synthèse vocale." }
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("La reconnaissance vocale n'est pas disponible sur cet appareil."); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "J'écoute. Parlez maintenant." }
            override fun onBeginningOfSpeech() { status.text = "Voix détectée…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Analyse en cours…" }
            override fun onError(error: Int) { status.text = "Écoute terminée. Appuyez pour réessayer." }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) { transcript.text = "VOUS : $spoken"; command(spoken) }
                status.text = "Système prêt."
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez à JARVIS SAM")
        }
        recognizer?.startListening(intent)
    }

    private fun command(raw: String) {
        val q = raw.trim()
        val s = q.lowercase(Locale.FRENCH)
        when {
            s.contains("bonjour") || s.contains("salut jarvis") ->
                respond("Bonjour. JARVIS SAM est opérationnel. Comment puis-je vous assister ?")
            s.contains("quelle heure") || s == "heure" ->
                respond("Il est " + java.text.SimpleDateFormat("HH:mm", Locale.FRANCE).format(java.util.Date()) + ".")
            s.contains("quelle date") || s.contains("date d'aujourd'hui") ->
                respond("Nous sommes le " + java.text.SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(java.util.Date()) + ".")
            s.contains("batterie") -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                respond("La batterie est à ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} pour cent.")
            }
            s.contains("ouvre youtube") || s.contains("ouvrir youtube") -> openUrl("https://www.youtube.com")
            s.contains("ouvre google") || s.contains("ouvrir google") -> openUrl("https://www.google.com")
            s.contains("ouvre whatsapp") || s.contains("ouvrir whatsapp") -> {
                val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launch != null) startActivity(launch) else respond("WhatsApp n'est pas installé ou n'est pas accessible.")
            }
            s.contains("recherche") || s.contains("cherche sur internet") -> {
                val search = q.replace(Regex("(?i)jarvis sam|jarvis|recherche|cherche sur internet"), "").trim()
                openUrl("https://www.google.com/search?q=" + Uri.encode(search))
            }
            else -> askAi(q)
        }
    }

    private fun askAi(question: String) {
        val endpoint = endpointInput.text.toString().trim()
        if (endpoint.isBlank()) {
            respond("Je peux exécuter mes commandes locales. Pour répondre à des questions complexes, configure d'abord le serveur d'intelligence artificielle sécurisé.")
            return
        }
        status.text = "Connexion au noyau IA…"
        thread {
            var result = "Je n'ai pas pu joindre le service IA. Vérifiez la connexion."
            try {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 12000; readTimeout = 25000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                conn.outputStream.use { it.write(JSONObject().put("message", question).toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode in 200..299) result = JSONObject(body).optString("reply", result)
                conn.disconnect()
            } catch (_: Exception) {}
            runOnUiThread { status.text = "Système prêt."; respond(result) }
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { respond("Impossible d'ouvrir cette page pour le moment.") }
    }

    private fun respond(message: String) {
        transcript.text = "JARVIS SAM : $message"
        status.text = "Réponse prête."
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_sam_reply")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
