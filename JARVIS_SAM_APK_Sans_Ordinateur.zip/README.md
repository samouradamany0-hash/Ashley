# JARVIS SAM — application Android

Projet source Kotlin/Android Studio personnalisé :
- Nom : JARVIS SAM
- Voix : essaie une voix française disponible sur le téléphone, avec un débit et une hauteur abaissés pour une tonalité d'assistant de science-fiction. La voix exacte dépend du moteur TTS installé.
- Style : interface sombre et cyan futuriste
- Commandes locales : heure, date, batterie, recherche Web, ouvrir Google/YouTube/WhatsApp
- Reconnaissance vocale française
- Intégration IA optionnelle via endpoint HTTPS `POST {"message":"..."}` renvoyant `{"reply":"..."}`

## Construire l'APK
1. Installe Android Studio depuis https://developer.android.com/studio sur un ordinateur.
2. Ouvre ce dossier comme projet.
3. Laisse Gradle se synchroniser et installe le SDK Android demandé.
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK de test se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

Ce ZIP est le code source, pas un APK compilé. Compiler l'APK nécessite Android Studio/Gradle et le SDK.

## Activer l'IA
Déploie `backend/server.py` sur un serveur privé derrière HTTPS, avec authentification et limitation des requêtes. Installe les dépendances depuis `backend/requirements.txt` et définis `OPENAI_API_KEY` dans l'environnement serveur. Ne place jamais la clé API dans l'application Android. Configure ensuite l'URL HTTPS complète de `/chat` dans le champ de l'application.

## Limites de cette version
Le mot d'activation permanent « Salut Jarvis », les appels automatiques, les SMS, les rappels système, le contrôle de la lampe torche et l'automatisation complète ne sont pas activés. Les autorisations Android et l'intégration de services spécifiques sont nécessaires pour les ajouter. La voix exacte façon cinéma ne peut pas être garantie par le TTS Android standard.


## Compiler sans ordinateur (GitHub Actions)
Ce projet contient un workflow `.github/workflows/build-apk.yml`.
1. Crée un dépôt GitHub et téléverse le contenu de ce dossier.
2. Ouvre l'onglet Actions du dépôt.
3. Si GitHub demande de confirmer les workflows, accepte.
4. Choisis « Build JARVIS SAM APK », puis « Run workflow ».
5. Une fois le travail terminé en vert, ouvre-le et télécharge l'artefact `JARVIS-SAM-APK`.
6. Décompresse l'artefact ZIP pour obtenir l'APK.

L'artefact est un APK de test signé avec la clé de débogage Android. Le workflow compile le code; il ne configure pas automatiquement le serveur IA.
